# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
SalorRetail::Application.config.secret_token = 'dc72ea04dbfd2f67b0e93debfb5668c970e1aecb67b13d362f0b4900c49e941a4e6c6001f99677c553f5616bbef1e7edc8259613e540874936fc286e398bb404'
